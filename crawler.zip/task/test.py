import time
while True:
    print(time.time())
    time.sleep(30)