# coding=utf-8
from proxy import Proxy
# 快代理
class kuaidaili(Proxy):
    pass

if __name__ == '__main__':
    test = kuaidaili()
    test.run()